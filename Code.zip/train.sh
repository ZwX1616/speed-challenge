python train.py --split 0.3 data/prepared-data/train_flow_meta.csv
